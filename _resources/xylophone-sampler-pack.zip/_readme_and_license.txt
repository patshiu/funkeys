Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by juancamiloorjuela ( http://www.freesound.org/people/juancamiloorjuela/  )
You can find this pack online at: http://www.freesound.org/people/juancamiloorjuela/packs/13065/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 204648__juancamiloorjuela__xylophone-g4.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204648/
    * license: Creative Commons 0
  * 204647__juancamiloorjuela__xylophone-a3.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204647/
    * license: Creative Commons 0
  * 204646__juancamiloorjuela__xylophone-c4.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204646/
    * license: Creative Commons 0
  * 204645__juancamiloorjuela__xylophone-d4.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204645/
    * license: Creative Commons 0
  * 204644__juancamiloorjuela__xylophone-e4.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204644/
    * license: Creative Commons 0
  * 204643__juancamiloorjuela__xylophone-f4.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204643/
    * license: Creative Commons 0
  * 204642__juancamiloorjuela__low-intesity-f4.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204642/
    * license: Creative Commons 0
  * 204641__juancamiloorjuela__low-intesity-g3.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204641/
    * license: Creative Commons 0
  * 204640__juancamiloorjuela__low-intesity-g4.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204640/
    * license: Creative Commons 0
  * 204639__juancamiloorjuela__xylophone-a4.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204639/
    * license: Creative Commons 0
  * 204638__juancamiloorjuela__xylophone-g3.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204638/
    * license: Creative Commons 0
  * 204637__juancamiloorjuela__xylophone-f3.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204637/
    * license: Creative Commons 0
  * 204636__juancamiloorjuela__xylophone-c3.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204636/
    * license: Creative Commons 0
  * 204635__juancamiloorjuela__xylophone-b3.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204635/
    * license: Creative Commons 0
  * 204634__juancamiloorjuela__xylophone-e3.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204634/
    * license: Creative Commons 0
  * 204633__juancamiloorjuela__xylophone-d3.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204633/
    * license: Creative Commons 0
  * 204632__juancamiloorjuela__low-intesity-e4.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204632/
    * license: Creative Commons 0
  * 204631__juancamiloorjuela__low-intesity-f3.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204631/
    * license: Creative Commons 0
  * 204630__juancamiloorjuela__low-intesity-c4.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204630/
    * license: Creative Commons 0
  * 204629__juancamiloorjuela__low-intesity-d3.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204629/
    * license: Creative Commons 0
  * 204628__juancamiloorjuela__low-intesity-d4.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204628/
    * license: Creative Commons 0
  * 204627__juancamiloorjuela__low-intesity-e3.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204627/
    * license: Creative Commons 0
  * 204626__juancamiloorjuela__low-intesity-a3.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204626/
    * license: Creative Commons 0
  * 204625__juancamiloorjuela__low-intesity-a4.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204625/
    * license: Creative Commons 0
  * 204624__juancamiloorjuela__low-intesity-b3.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204624/
    * license: Creative Commons 0
  * 204623__juancamiloorjuela__low-intesity-c3.wav
    * url: http://www.freesound.org/people/juancamiloorjuela/sounds/204623/
    * license: Creative Commons 0

